function G = poly2(U,V)
    % homogeneous polynomial kernel, d = 2
    G = (U*V').^2;
end