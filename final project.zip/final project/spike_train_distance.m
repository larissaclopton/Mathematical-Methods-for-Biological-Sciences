%% single neuron metric

clear all; close all;
pause(1)

figmarkersize = 10;
figlinewidth = 2;
figfontsize = 14;

tic
disp('loading')

% load('example_data.mat');
load('rawdata_byRF_Macallan_discrimination_D5d_HP250.mat');
% load('rawdata_byRF_Macallan_discrimination_W4_HP250.mat');
% load('rawdata_byRF_Pabst_discrimination_D2p_HP250.mat');

toc



data = byRF_struct;

block_idx = 1:length(data.trialNumber);


%find hotspot electrode
[hotspot_elec stim1_responses stim2_responses] = find_hotspot_electrode(data, block_idx);
% elecList = hotspot_elec;
elecList = 1:96;



% calculate van rossum distance between each trial stimulus 1/2 spiketrains
% elec rows columns trials, stacked blocks
disp('calculating V.R. distance')
tic
distance_squared = van_rossum_distance(data, elecList, block_idx);
toc


%%


%this is the minimum # of both correct and incorrect trials
minimum_n = 3;


[S sort_idx] = sort(stim2_responses);

N = 3;
individual_elecs_plot = [sort(sort_idx(end-N:end))];





% stack all the blocks
amplitudes = [];
behavior = [];
for b = block_idx
    
    amplitudes = [amplitudes; data.amplitude{b}];
    behavior = [behavior; data.correctResponse{b}];

end




% remove bad trials
badTrial_idx = behavior~= 0 & behavior~= 1;
amplitudes(badTrial_idx,:) = [];
behavior(badTrial_idx) = [];
distance_squared(:, badTrial_idx) = [];





% compute and sort by absolute amplitude differences
amp_diff = abs(amplitudes(:,1) - amplitudes(:,2));
[sorted_amp,idxs] = sort(amp_diff);




%loop through each electrode
distance_correct_mean = {};
distance_incorrect_mean = {};
distance_correct_std = {};
distance_incorrect_std = {};
distance_correct = {};
distance_incorrect = {};
linear_fit_coeffs = nan(length(elecList), 2);
distance_from_unity = nan(length(elecList), 1);
for e = 1:length(elecList)
    
    sorted_dist = sqrt(distance_squared(e, idxs)); % sort distances by amplitude difference

    % loop through amplitude combinations, for each look at distance and
    % behavioral result
    
    AMPS = unique(amplitudes(:));
    
    distance_correct_mean{e} = nan(length(AMPS));
    distance_incorrect_mean{e} = nan(length(AMPS));
    distance_correct_std{e} = nan(length(AMPS));
    distance_incorrect_std{e} = nan(length(AMPS));
    distance_correct{e} = cell(length(AMPS));
    distance_incorrect{e} = cell(length(AMPS));
    n_correct = nan(length(AMPS));
    n_incorrect = nan(length(AMPS));
    for a = 1:length(AMPS)
        for b = 1:length(AMPS)
            
            combo_idx = amplitudes(:, 1) == AMPS(a) & amplitudes(:, 2) == AMPS(b);
            
            if sum(combo_idx) > 0
                D = distance_squared(e, combo_idx);
                B = behavior(combo_idx)';
                
                distance_correct{e}{a}{b} = D(B == 1);
                distance_incorrect{e}{a}{b} = D(B == 0);
                
                distance_correct_mean{e}(a, b) = mean(D(B == 1));
                distance_incorrect_mean{e}(a, b) = mean(D(B == 0));
                
                distance_correct_std{e}(a, b) = std(D(B == 1));
                distance_incorrect_std{e}(a, b) = std(D(B == 0));
                
                n_correct(a, b) = sum(B == 1);
                n_incorrect(a, b) = sum(B == 0);
                
            end
        end
    end
    
%     correct_over_incorrect = distance_correct_mean{e} ./ distance_incorrect_mean{e};
    

     %get rid of combos with too few trials correct or incorrect
     nc = n_correct(:);
     ni = n_incorrect(:);
     insufficient_n_idx = nc < minimum_n | ni < minimum_n;

     II = distance_incorrect_mean{e}(:);
     CC = distance_correct_mean{e}(:);
     II(insufficient_n_idx) = nan;
     CC(insufficient_n_idx) = nan;
     
     
     
     diffs = unique(sorted_amp);
     neural_diffs = nan(1, length(diffs));
     for i = 1:length(diffs)
         diff_idx = sorted_amp == diffs(i);
         neural_diffs(i) = mean(sorted_dist(diff_idx));
     end
     
     
     % do a linear fit of neural and stimulus amp distance
     linear_fit_coeffs(e, :) = polyfit(diffs, neural_diffs', 1);
     X = [0:10:max(diffs)];
     Y = X*linear_fit_coeffs(e, 1) + linear_fit_coeffs(e, 2);
     
     
     % calculate population distance from unity line (positive for over), normalized
     distance_from_unity(e) = nansum(CC - II) / nansum(CC);
     
     
     
     % make plots for each elec
     if ismember(elecList(e), individual_elecs_plot)
         
         %     figure; hold on;
         %     for i = 1:length(behavior)
         %         if behavior(idxs(i)) == 1
         %             color = 'b';
         %         else
         %             color = 'r';
         %         end
         %         scatter(sorted_amp(i),sorted_dist(i),color);
         %     end
         %     xlabel('Amplitude difference'); ylabel('Distance');
         %     title(['Distance vs amplitude difference, elec ' num2str(elecList(e))]);
         %     ylim([0 max(sorted_dist)*1.1])
         
         
         % plot the mean distance for each amplitude difference
         figure
         subplot(1, 2, 1)
         hold on;
         
%          for i = 1:length(diffs)
%              diff_idx = sorted_amp == diffs(i);
%              scatter(diffs(i),mean(sorted_dist(diff_idx)));
%          end
         plot(diffs, neural_diffs, 'o', 'markersize', figmarkersize)
         hold on
         plot(X, Y, '-')
         xlabel('Amplitude difference'); ylabel('Mean distance');
         title(['elec ' num2str(elecList(e))]);
         ylim([0 max(sorted_dist)*1.1])
         text(max(diffs)*0.2, max(sorted_dist)*0.8, num2str(linear_fit_coeffs(e, :)))
         
         
         %plot distance in correct trials vs in incorrect trials
         subplot(1, 2, 2)
         hold on
         plot(II, CC, 'o', 'markersize', figmarkersize, 'linewidth', figlinewidth)
         max_dist = max([II; CC]);
         xlim([0 max_dist])
         ylim([0 max_dist])
         line([0 max_dist], [0 max_dist])
         %     title(['mean distances and behavior, for each amplitude pair, elec ' num2str(elecList(e))], 'fontsize', figfontsize)
         xlabel('distance in incorrect trials', 'fontsize', figfontsize)
         ylabel('distance in correct trials', 'fontsize', figfontsize)
         axis square
         
%          disp('paused between electrodes')
%          pause
         
     end
end



%sort everything by the slope of the fit between neural distance and amp distance
[sorted_linfit, idxs] = sort(linear_fit_coeffs(:, 1)');

sorted_dist_unity = distance_from_unity(idxs)';

sorted_elecs = elecList(idxs)


figure
plot(sorted_linfit, sorted_dist_unity,'o', 'markersize', figmarkersize)
title('relationship between correct/incorrect neural distance and neural/amp distance fit slope')
xlabel('dist vs amp linear fit slope')
ylabel('summed distance over corect/incorrect unity')
axis square


% Need to determine if distance measure correct
% Play with tc
% Need more trials
% Work on multineuron metric
% Implement spikernel

% Would say that incorrect performance somewhat positively correlated to
% smaller distance
% Not sure if distance increases for larger amplitude difference






