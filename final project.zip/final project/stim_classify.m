function [m_loss,m_std,labels,amps] = ...
    stim_classify(behavior,amplitudes,spikes,ntrials,nelecs,runs,binsize,block_trials)

    % Step 0 - find the hotspot electrodes
    [hotspot_elecs] = find_hotspot_electrode(amplitudes,spikes,ntrials,nelecs);

    % define the stimulus ranges
    stim1_range = [0 1.2]; % you can change this based on your data
    stim2_range = [2 3.2]; % you can change this based on your data
    baseline_range = [-0.5 0];

    % Step 1 - compute baseline firing rates for each electrode in each block,
    % using all trials in that block
    base_rates = zeros(length(block_trials),nelecs);
    bins = 0:binsize:0.5;
    for i = 1:length(block_trials)
        for j = 1:nelecs
            base_spikes = [];
            if i == 1
                trial_range = 1:block_trials(i);
            else
                trial_range = block_trials(i-1)+1:block_trials(i);
            end
            for t = trial_range
                trial_spikes = spikes{hotspot_elecs(j)}{t};

                new_spikes = trial_spikes(trial_spikes > baseline_range(1) ...
                & trial_spikes < baseline_range(2)) - baseline_range(1);

                base_spikes = [base_spikes new_spikes];
            end

            if i == 1
                diff = block_trials(i);
            else
                diff = block_trials(i)-block_trials(i-1);
            end
            base_rate = histc(base_spikes,bins)/(diff*binsize);
            base_rates(i,j) = mean(base_rate);
        end
    end

    % Step 2 - compute firing rates at these electrodes
    bins = 0:binsize:1.2;
    firing_rates = [];
    block = 1;
    for i = 1:nelecs

        elec_rates = zeros(2*ntrials,length(bins));
        for t = 1:ntrials
            % determine the base rate to normalize by
            if t == block_trials(block)+1
                block = block + 1;
            end
            base_rate = base_rates(block,i);

            % retrieve the spike times for this trial at the given electrode
            trial_spikes = spikes{hotspot_elecs(i)}{t};

            spikes1 = trial_spikes(trial_spikes > stim1_range(1) ...
                & trial_spikes < stim1_range(2));
            spikes2 = trial_spikes(trial_spikes > stim2_range(1) ...
                & trial_spikes < stim2_range(2)) - stim2_range(1);

            % compute instantaneous firing rates at binned time windows for both stimuli
            elec_rates(2*(t-1)+1:2*(t-1)+2,:) = ...
                [histc(spikes1,bins)/(base_rate*binsize); histc(spikes2,bins)/(base_rate*binsize)];

        end
        firing_rates = cat(2,firing_rates,elec_rates);

    end

    % you do not need this part
    % Step 3 - clean up the data
    % remove bad trials
    badTrial_idx = find(behavior ~= 0 & behavior ~= 1);
    badTrials = zeros(1,2*length(badTrial_idx));
    for t = 1:length(badTrial_idx)
        badTrials(2*(t-1)+1) = 2*badTrial_idx(t);
        badTrials(2*(t-1)+2) = 2*badTrial_idx(t)+1;
    end
    firing_rates(badTrials,:) = [];
    amps = amplitudes; % copy over the amplitudes
    amps(badTrial_idx,:) = [];
    % flatten the amplitudes
    amps = amps';
    amps = amps(:);
    
    % only keep trials of amplitudes - 150,1000,2000
    % this line balances the amplitudes
    %idxs = cat(1,cat(1,find(amps == 150,140),find(amps == 1000,140)),find(amps == 2000,140));
    % this line does not balance the amplitudes
    idxs = find(amps == 150 | amps == 1000 | amps == 2000);
    amps = amps(idxs);
    nexamples = length(amps); % number of training examples
    firing_rates = firing_rates(idxs,:);
    
    % Step 4 - binary amplitude classification
    % i.two close, middle amplitudes
    % ii.two moderately separated amplitudes
    % iii.two far apart amplitudes
%     pairs = [600 750; 250 750; 125 2000];
%     binary_loss = zeros(runs,3); % hold classification losses of each pair
%     for i = 1:3
% 
%         % obtain the model from fitcvsm
%         amp1 = pairs(i,1); amp2 = pairs(i,2);
%         idxs = find(amps == amp1 | amps == amp2);
%         X = firing_rates(idxs,:);
%         Y = amps(idxs);
%         Model = fitcsvm(X,Y,'KernelFunction','poly2','Standardize',true);
%         for j = 1:runs
%             % cross validate the model and obtain the loss
%             crossval_Model = crossval(Model,'KFold',5); % THIS CAN BE CHANGED
%             binary_loss(j,i) = kfoldLoss(crossval_Model);
%         end
% 
%     end

    % obtain the average and standard deviation of the binary_loss
%     b_loss = mean(binary_loss);
%     b_std = std(binary_loss);

    % Step 5 - multiclass amplitude classification

%     tmp_fr = [];
%     tmp_amps = [];

    % TEMPORARY
%     u = unique(amps);
%     for i = 1:length(u)
%         idxs = find(amps == u(i), 70);
%         tmp_fr = cat(1,tmp_fr,firing_rates(idxs,:));
%         tmp_amps = cat(1,tmp_amps,amps(idxs));
%     end

    
    all_labels = zeros(runs,nexamples);
    t = templateSVM('Standardize',1,'KernelFunction','poly2');
%   Model = fitcecoc(tmp_fr,tmp_amps,'Learners',t);
    Model = fitcecoc(firing_rates,amps,'Learners',t,'Coding','onevsall');
    multiclass_loss = zeros(runs,1);
    for i = 1:runs
        % cross validate the model and obtain the loss
        crossval_Model = crossval(Model,'KFold',5); % THIS CAN BE CHANGED
        multiclass_loss(i) = kfoldLoss(crossval_Model);
        % obtain the labels and scores
        labels = kfoldPredict(crossval_Model);
        all_labels(i,:) = labels;
    end

    % return the most common label
    labels = mode(all_labels);

    m_loss = mean(multiclass_loss);
    m_std = std(multiclass_loss);

end

        