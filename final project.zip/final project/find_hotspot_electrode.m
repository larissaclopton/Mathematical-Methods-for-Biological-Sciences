function [hotspot_elecs] = find_hotspot_electrode(amplitudes,spikes,ntrials,nelecs)

% set stimulus and baseline ranges
stim1_range = [0 1.2];
stim2_range = [2 3.2];
baseline1_range = [-0.5 0];
baseline2_range = [1.3 2];

% check that baseline and stim interval lengths are equal
if diff(baseline1_range) + diff(baseline2_range) ~= diff(stim1_range)
    disp('baseline and stim interval lengths do not match')
    return
end

maxamp = max(amplitudes(:, 1));
maxamp_idx_stim1 = amplitudes(:, 1) == maxamp;

% spike counts matrix, elec rows and trial columns
stim1_count = nan(nelecs, ntrials);
stim2_count = nan(nelecs, ntrials);
baseline_count = nan(nelecs, ntrials);
for elec = 1:nelecs
    for t = 1:ntrials
        
        timestamps = spikes{elec}{t};
        
        stim1_count(elec,t) = sum(timestamps > stim1_range(1) & timestamps < stim1_range(2));
        stim2_count(elec,t) = sum(timestamps > stim2_range(1) & timestamps < stim2_range(2));
        
        A = sum(timestamps > baseline1_range(1) & timestamps < baseline1_range(2));
        B = sum(timestamps > baseline2_range(1) & timestamps < baseline2_range(2));
        baseline_count(elec,t) = A + B;
        
    end
end

baseline_mean = mean(baseline_count,2);
baseline_std = std(baseline_count,0,2);
stim1_mean = mean(stim1_count(:,maxamp_idx_stim1),2);
stim1_responses = (stim1_mean - baseline_mean) ./ baseline_std;

% select hotspot elec as the highest response electrode for stim interval 1
[~,idxs] = sort(stim1_responses,'descend');
hotspot_elecs = idxs(1:nelecs);











