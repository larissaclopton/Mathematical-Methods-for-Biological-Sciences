function [m_loss,m_std,labels,actual_labels] = ...
    stim2_classify(type,actual_labels,amplitudes,spikes,ntrials,nelecs,runs,binsize,block_trials)

    % Step 0 - find the hotspot electrodes
    [hotspot_elecs] = find_hotspot_electrode(amplitudes,spikes,ntrials,nelecs);

    % define the stimulus ranges
    stim_range = [0 1.2];
    baseline_range = [-0.5 0];

    % Step 1 - compute baseline firing rates for each electrode in each block,
    % using all trials in that block
    base_rates = zeros(length(block_trials),nelecs);
    bins = 0:binsize:0.5;
    for i = 1:length(block_trials)
        for j = 1:nelecs
            base_spikes = [];
            if i == 1
                trial_range = 1:block_trials(i);
            else
                trial_range = block_trials(i-1)+1:block_trials(i);
            end
            for t = trial_range
                trial_spikes = spikes{hotspot_elecs(j)}{t};

                new_spikes = trial_spikes(trial_spikes > baseline_range(1) ...
                & trial_spikes < baseline_range(2)) - baseline_range(1);

                base_spikes = [base_spikes new_spikes];
            end

            if i == 1
                diff = block_trials(i);
            else
                diff = block_trials(i)-block_trials(i-1);
            end
            %base_rate = histc(base_spikes,bins)/(diff*binsize);
            base_rate = histc(base_spikes,bins)/(diff);
            base_rates(i,j) = mean(base_rate);
        end
    end
     
    % Step 2 - compute firing rates at these electrodes
    bins = 0:binsize:1.2;
    firing_rates = [];
    block = 1;
    for i = 1:nelecs

        elec_rates = zeros(ntrials,length(bins));
        for t = 1:ntrials
            % determine the base rate to normalize by
            if t == block_trials(block)+1
                block = block + 1;
            end
            base_rate = base_rates(block,i);

            % retrieve the spike times for this trial at the given electrode
            trial_spikes = spikes{hotspot_elecs(i)}{t};
            spikes1 = trial_spikes(trial_spikes > stim_range(1) ...
                & trial_spikes < stim_range(2)); % note - there is only one stimulus
 
            % compute instantaneous firing rates at binned time windows for both stimuli
            if isempty(spikes1)
                elec_rates(t,:) = zeros(1,length(bins));
            else
                %elec_rates(t,:) = histc(spikes1,bins)/(base_rate*binsize);
                res = histc(spikes1,bins);
                elec_rates(t,:) = res/(base_rate);
            end

        end
        firing_rates = cat(2,firing_rates,elec_rates);

    end

    if type == 'amp'
        % only keep trials of amplitudes - 150,1000,2000
        idxs = find(actual_labels == 150 | actual_labels == 1000 | actual_labels == 2000);
        actual_labels = actual_labels(idxs);
        firing_rates = firing_rates(idxs,:);
    end
    
    % Step 3 - multiclass classification
    nexamples = length(actual_labels);
    all_labels = zeros(runs,nexamples);
    
    t = templateSVM('Standardize',1,'KernelFunction','polynomial','PolynomialOrder',3);
    Model = fitcecoc(firing_rates,actual_labels,'Learners',t);
    %Model = fitcecoc(firing_rates,actual_labels,'Learners',t,'Coding','onevsall');
    multiclass_loss = zeros(runs,1);
    for i = 1:runs
        % cross validate the model and obtain the loss
        crossval_Model = crossval(Model,'KFold',5); % THIS CAN BE CHANGED
        multiclass_loss(i) = kfoldLoss(crossval_Model);
        % obtain the labels
        labels = kfoldPredict(crossval_Model);
        all_labels(i,:) = labels;
    end
    
    % return the most common label
    labels = mode(all_labels);

    m_loss = mean(multiclass_loss);
    m_std = std(multiclass_loss);
    
end