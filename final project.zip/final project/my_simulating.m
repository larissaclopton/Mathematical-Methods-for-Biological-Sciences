% This is the fake data generate function
% input:amplitudes:the stimulate amplitudes from Therri's example data
% tSim: time of stimulation according to Therri's recording, for each amplitudes, it is 1s.
% dt:recoding time bin
% for this simulation, the neuron spikes according to the amplitudes of the
% stimulation


function [sim_sample]=my_simulating(amplitudes,tSim,dt)
nTrials=length(amplitudes(:,1));
sim_sample=cell(1,nTrials);
spikeM=[]; tV=[];
for d=1:length(amplitudes(1,:))+1
if d>1    
    amp=amplitudes(:,4-d);
    fr=amp/1000*100+10;
end    
    spikeMat=[];
    tVec=[];
        
    
for j=1:nTrials
    if d==1
        rate=10;
[spikeMat(j,:), tVec] = poissonSpikeGen(rate, 0.5, 1,dt);
    else
        [spikeMat(j,:), tVec] = poissonSpikeGen(fr(j), 1, 1,dt);
        tVec=tVec+0.5+d*2-4;
    end
end
inter=zeros(nTrials,1000);
intert=zeros(1,1000);
if d==2
    spikeMat=[spikeMat inter];
    tVec=[tVec intert];
end

spikeM=[spikeM spikeMat];
tV=[tV tVec];


end

% figure
% plotRaster(spikeM, tV)
tV=tV-0.5;
for i=1:nTrials
sim_sample{i}=tV(spikeM(i,:)==1);

end


end