function [spikeMat, tVec] = poissonSpikeGen(fr, tSim, nTrials,dt)

nBins = str2num(num2str(tSim/dt));
spikeMat = rand(nTrials, nBins) < fr*dt;
tVec = 0:dt:tSim-dt;
end