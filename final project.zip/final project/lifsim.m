

function [tspikeind]=lifsim(amplitudes,tSim,dt)
% membrane constants
tau = 0.020;
R = 3e7;
% resting potential
E = -0.070;
% threshold for a spike
theta = -0.030;


% total number of steps
no_steps = round(tSim ./ dt);
% time - for plotting
time = linspace(0, tSim, no_steps + 1);


tau_s = 0.003; %should be less than tau



nTrials=length(amplitudes(:,1));
tspikeind=cell(1,nTrials);
rate=10; %micron/ms


for trial=1:nTrials
% voltage matrix
V = zeros(1, no_steps + 1);
% initial voltage of membrane - put at rest
V(1) = -0.07;
tV=[];    

 
for d=1:length(amplitudes(1,:))
     I=[];  
         amp=amplitudes(:,d);
    part0=150/10/1000;
    part1=(amp/rate)/1000;
    part2=1-part1*2-part0;
    part3=part1;
     
% current
if d==1
    
I0 = zeros(1,( (0.5+part0)/dt)+1)+4e-10;
else
    I0=zeros(1,( part0/dt)+1)+4e-10;
end    
I1=zeros(1,ceil(str2num(num2str(part1(trial)/dt))))+6e-9;
I2=zeros(1,str2num(num2str(part2(trial)/dt)))+9e-10;
I3=zeros(1,floor(str2num(num2str(part3(trial)/dt))))+6e-9;

I=[I0 I1 I2 I3];

randI = 5e-9 .* random('Normal', 0,2, [1, no_steps]);
% time since last spike
t_spike = [];
% absolute refactory period
arp = 0.01; %this being 0.02 doesn't work.
% total number of spikes
no_spikes = 0;

if d==1
for i=1:1500

    
    dV =(dt/tau).*(E-V(i)+I(i).*R + randI(i).*R);
    % update without noise
    % dV =(dt/tau).*(E-V(i)+I(i).*R);
    V(i+1) = V(i) + dV;
    % spike
    if (V(i+1) > theta) 
        if no_spikes>0
            % check we're not in absolute refac period
            if (time(i)>=(t_spike+arp))
                % reset voltage
                V(i+1) = E;
                % Eleni's trick of making spikes look nice
                V(i) = -0;
                % record spike
                t_spike = [t_spike time(i)];
                % increment spike count
                no_spikes = no_spikes+1;


            end
        else
            % no spikes yet - no need to check
            V(i+1) = E;
            % Eleni's trick of making spikes look nice
            V(i) = -0;
            % record spike
            t_spike = [t_spike time(i)];
            % increment spike count
            no_spikes = no_spikes+1;

 
        end
    end
    
    
    
end
else
for i=1:1000

    
    dV =(dt/tau).*(E-V(i)+I(i).*R + randI(i).*R);
    % update without noise
    % dV =(dt/tau).*(E-V(i)+I(i).*R);
    V(i+1) = V(i) + dV;
    % spike
    if (V(i+1) > theta) 
        if no_spikes>0
            % check we're not in absolute refac period
            if (time(i)>=(t_spike+arp))
                % reset voltage
                V(i+1) = E;
                % Eleni's trick of making spikes look nice
                V(i) = -0;
                % record spike
                t_spike = [t_spike time(i)];
                % increment spike count
                no_spikes = no_spikes+1;


            end
        else
            % no spikes yet - no need to check
            V(i+1) = E;
            % Eleni's trick of making spikes look nice
            V(i) = -0;
            % record spike
            t_spike = [t_spike time(i)];
            % increment spike count
            no_spikes = no_spikes+1;

 
        end
    end
    
end
t_spike=t_spike+2.5;
end
tV=[tV t_spike];

end
tspikeind{trial}=tV-0.5;

end
% plotRaster(tspikeind);
end
% 

% figure;
% plot(time, V, 'color', 'black');
% hold on
% plot(time, theta, '--r');
% line1 = 'Leaky integrate-and-fire model with noise';
% line2 = sprintf('theta: %.3fV, refactory period: %.2fs',theta, arp);
% title({line1, line2});
% xlabel('time (s)')
% ylabel('voltage (V)')
% grid on