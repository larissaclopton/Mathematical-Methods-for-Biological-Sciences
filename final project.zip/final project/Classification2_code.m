%% Classification code (amplitude and tip size)
% multiple skin locations and multiple sets of top electrodes

clear all; close all;
load('rawdata_byRF_Pabst_tipSize_D4d_HP100.mat');

% NOTE - change these each time, used for saving the data
description = 'binsize 0.1; amplitudes 150, 1000, 2000; onevsall';
filename = 'Amp&Tip-Run5';

nelec = [1 5 10]; % number of electrodes
runs = 10; % number of times to run the classification    
binsize = 0.1; % THIS CAN BE CHANGED

% matrices/cell-arrays to save amp data
amp_multi_loss = zeros(1,length(nelec));
amp_multi_std = zeros(1,length(nelec));
all_amp_labels = cell(1,length(nelec));

% matrices/cell-arrays to save tip size data
tip_multi_loss = zeros(1,length(nelec));
tip_multi_std = zeros(1,length(nelec));
all_tip_labels = cell(1,length(nelec));

% format the data, combining blocks
nblocks = length(byRF_struct.amplitude); % number of blocks
block_trials = zeros(1,nblocks);
amplitudes = [];
tipsizes = [];
spikes = cell(1,96);

for i = 1:nblocks
   if i == 1
       block_trials(i) = length(byRF_struct.trialspiketimes{1,i}{1,1});
   else
       block_trials(i) = block_trials(i-1) + length(byRF_struct.trialspiketimes{1,i}{1,1});
   end
   amplitudes = cat(1,amplitudes,byRF_struct.amplitude{i}(:,1));
   tipsizes = [tipsizes repelem(byRF_struct.tipSize(i),length(byRF_struct.trialspiketimes{1,i}{1,1}))];
   for j = 1:96
       spikes{j} = cat(2,spikes{j},byRF_struct.trialspiketimes{1,i}{1,j});
   end
end
ntrials = length(spikes{1}); % the total number of trials

% amplitude and tip size classification
for i = 1:length(nelec)
    disp([num2str(nelec(i)) ' electrodes']);
    
    % run binary and multiclass amplitude classification
    % using data from the given number of top electrodes
    disp('Amplitude classification');
    [m_loss,m_std,labels,subset] = ...
         stim2_classify('amp',amplitudes,amplitudes,spikes,ntrials,nelec(i),runs,binsize,block_trials);
    display(m_loss); display(m_std);
        
    % store the amplitude results
    amp_multi_loss(i) = m_loss;
    amp_multi_std(i) = m_std;    
    all_amp_labels{i} = labels;
        
    % plot histograms of predicted amplitudes for each actual amplitude
    n = length(subset);
    isLabels = unique(subset);
    nlabels = numel(isLabels);
    for j = 1:nlabels
        figure;
        histogram(labels(subset == isLabels(j)));
        xlabel('Predicted Amplitude'); ylabel('Count');
        title([num2str(isLabels(j)) ' : Prediction histogram']);
    end
%         
%     % plot a confusion matrix
% %     ConfMat = confusionmat(subset,labels);
% %     % Convert the integer label vector to a class-identifier matrix.
% %     [~,grplabels] = ismember(labels,isLabels); 
% %     labelMat = zeros(nlabels,n); 
% %     idxLinear = sub2ind([nlabels n],grplabels',(1:n)'); 
% %     labelMat(idxLinear) = 1; % Flags the row corresponding to the class 
% %     [~,grpY] = ismember(subset,isLabels); 
% %     YMat = zeros(nlabels,n); 
% %     idxLinearY = sub2ind([nlabels n],grpY,(1:n)'); 
% %     YMat(idxLinearY) = 1; 
% % 
% %     figure;
% %     plotconfusion(YMat,labelMat);
% %     h = gca;
% %     h.XTickLabel = [num2cell(isLabels); {''}];
% %     h.YTickLabel = [num2cell(isLabels); {''}];
%      
    % run multiclass tip size classification using 
    % data from the given number of top electrodes
    disp('Tip size classification');
    [m_loss,m_std,labels,subset] = ...
         stim2_classify('tip',tipsizes,amplitudes,spikes,ntrials,nelec(i),runs,binsize,block_trials);
    display(m_loss); display(m_std);
    
    % store the tip size results
    tip_multi_loss(i) = m_loss;
    tip_multi_std(i) = m_std;    
    all_tip_labels{i} = labels;
    
    % plot histograms of predicted tip sizes for each actual tip size
     n = length(subset);
     isLabels = unique(subset);
     nlabels = numel(isLabels);
     for j = 1:nlabels
         figure;
         histogram(labels(tipsizes == isLabels(j)));
         xlabel('Predicted Tip Size'); ylabel('Count');
         title([num2str(isLabels(j)) ' : Prediction histogram']);
     end
    
     % plot a confusion matrix
%      ConfMat = confusionmat(subset,labels);
%      % Convert the integer label vector to a class-identifier matrix.
%      [~,grplabels] = ismember(labels,isLabels); 
%      labelMat = zeros(nlabels,n); 
%      idxLinear = sub2ind([nlabels n],grplabels',(1:n)'); 
%      labelMat(idxLinear) = 1; % Flags the row corresponding to the class 
%      [~,grpY] = ismember(subset,isLabels); 
%      YMat = zeros(nlabels,n); 
%      idxLinearY = sub2ind([nlabels n],grpY,(1:n)'); 
%      YMat(idxLinearY) = 1; 
% 
%      figure;
%      plotconfusion(YMat,labelMat);
%      h = gca;
%      h.XTickLabel = [num2cell(isLabels); {''}];
%      h.YTickLabel = [num2cell(isLabels); {''}];
     
end
      
% multi_loss with n electrodes versus multi_loss with one electrode
amp_loss_ratio = amp_multi_loss/amp_multi_loss(1);
display(amp_loss_ratio);
tip_loss_ratio = tip_multi_loss/tip_multi_loss(1);
display(tip_loss_ratio);

% save the data
save(filename,'nelec','runs','binsize','amp_multi_loss','amp_multi_std',...
    'amp_loss_ratio','all_amp_labels',...
    'tip_multi_loss','tip_multi_std','tip_loss_ratio','all_tip_labels',...
    'amplitudes','tipsizes','description');