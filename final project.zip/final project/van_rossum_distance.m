function distance_squared = van_rossum_distance(data, elec, block_idx)



if nargin < 2
    elec = 1:length(data.trialspiketimes_goodwaves{1});
end

if nargin < 3
    block_idx = 1:length(data.trialNumber);
end


% calculate distance_squared metric

timevec = 0:0.01:1;  

tc = 0.05; % tc is a tuneable parameter




% stack all the blocks
amplitudeMat = [];
timestampsMat = cell(1, length(data.trialspiketimes_goodwaves{1}));
for b = block_idx;
    
    amplitudeMat = [amplitudeMat; data.amplitude{b}];
    
    for e = 1:length(data.trialspiketimes_goodwaves{b})

        A = data.trialspiketimes_goodwaves{b}{e};
        timestampsMat{e} = [timestampsMat{e} A];
        
    end
end




distance_squared = nan(length(elec), length(amplitudeMat));
for e = 1:length(elec)
    for trial = 1:length(amplitudeMat)
        
        timestamps = timestampsMat{elec(e)}{trial};
        
        timestamps_stim1 = timestamps(timestamps > 0 & timestamps < 1);
        
        timestamps_stim2 = timestamps(timestamps > 2 & timestamps < 3);
        timestamps_stim2 = timestamps_stim2 - 2;
        
        % calculate "continuous" functions
        f = [];
        g = [];
        for t = 1:length(timevec)
            
            H1 = (timevec(t) - timestamps_stim1) >= 0;
            H2 = (timevec(t) - timestamps_stim2) >= 0;
            
            
            exponent1 = -(timevec(t) - timestamps_stim1)/tc;
            f(t) = sum(H1 .* exp(exponent1));
            
            exponent2 = -(timevec(t) - timestamps_stim2)/tc;
            g(t) = sum(H2 .*  exp(exponent2));
            
        end
        
        % QUESTION - is this the same as integrating?
        distance_squared(e, trial) = 1/tc * sum((f - g).^2);
        
    end
end


