clear all; close all;

load('rawdata_byRF_Macallan_discrimination_D3d_HP250.mat');
data = byRF_struct;
block_idx = size(data.trialspiketimes_goodwaves);
tSim=3.5;
dt=1/1000;
num=2;
for i=1:num
    
for block=1:block_idx(2)
ele=length(data.trialspiketimes_goodwaves{2});
for eletrode=1:ele
amplitudes = data.amplitude{block};
my_simsample=my_simulating(amplitudes,tSim,dt);
data.trialspiketimes_goodwaves{1,block}{1,eletrode}=my_simsample;
end
end
name=strcat('difratesim_','D3d_HP250',num2str(i),'.mat');
save(name,'data');
end
% figure;
% plotRaster(my_simsample)