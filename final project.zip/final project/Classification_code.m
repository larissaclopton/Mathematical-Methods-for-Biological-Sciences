%% Classification code (amplitude)
% multiple skin locations and multiple sets of top electrodes

clear all; close all;

% NOTE - change these each time, used for saving the data
description = 'binsize 0.1; amplitudes 150, 1000, 2000 (unbalanced)';
filename = 'AmpOnly-Run7'; % change this name to save the data

% NOTE - currently using skin locations with the most trials
% put your file name here
files = {'rawdata_byRF_Macallan_discrimination_D3d_HP250.mat';...
        'rawdata_byRF_Macallan_discrimination_W3_HP250.mat'};
nelec = [1 5 10]; % number of top electrodes
runs = 10; % number of times to run the classification    
binsize = 0.1;

% matrices/cell-arrays to save all the data
% binary_losses = zeros(length(files),length(nelec),3);
% binary_stds = zeros(length(files),length(nelec),3);
multi_loss = zeros(length(files),length(nelec));
multi_std = zeros(length(files),length(nelec));
loss_ratio = zeros(length(files),length(nelec));
all_amps = cell(length(files),length(nelec));
all_labels = cell(length(files),length(nelec));

for f = 1:length(files)
    display(files{f});
    load(files{f}); % loads new byRF_struct
 
    % format the data, combining blocks
    % change all of these to match the name of your data struct
    nblocks = length(byRF_struct.amplitude); % number of blocks
    block_trials = zeros(1,nblocks);
    amplitudes = [];
    behavior = []; % you won't need this
    spikes = cell(1,96);
    for i = 1:nblocks
        if i == 1
            block_trials(i) = length(byRF_struct.trialspiketimes_goodwaves{1,i}{1,1});
        else
            block_trials(i) = block_trials(i-1) + length(byRF_struct.trialspiketimes_goodwaves{1,i}{1,1});
        end
        amplitudes = cat(1,amplitudes,byRF_struct.amplitude{i});
        behavior = cat(1,behavior,byRF_struct.correctResponse{i}); % you won't need this
        for j = 1:96
            spikes{j} = cat(2,spikes{j},byRF_struct.trialspiketimes_goodwaves{1,i}{1,j});
        end
    end
    ntrials = length(spikes{1}); % the total number of trials
    
    for i = 1:length(nelec)
        disp([num2str(nelec(i)) ' electrodes']);
        % run binary and multiclass amplitude classification
        % using data from the given number of top electrodes
        % don't need to pass behavior to stim_classify
        [m_loss,m_std,labels,amps] = ...
            stim_classify(behavior,amplitudes,spikes,ntrials,nelec(i),runs,binsize,block_trials);
%         display(b_loss); display(b_std); 
        display(m_loss); display(m_std);
            
        % store the results
%         binary_losses(f,i,:) = b_loss;
%         binary_stds(f,i,:) = b_std;
        multi_loss(f,i) = m_loss;
        multi_std(f,i) = m_std;    
        all_amps{f}{i} = amps;
        all_labels{f}{i} = labels;
        
        % plot histograms of predicted amplitudes for each actual amplitude
        n = length(amps);
        isLabels = unique(amps);
        nlabels = numel(isLabels);
        for j = 1:nlabels
            figure;
            histogram(labels(amps == isLabels(j)));
            xlabel('Predicted Amplitude'); ylabel('Count');
            title([num2str(isLabels(j)) ' : Prediction histogram']);
        end

        % plot a confusion matrix
        ConfMat = confusionmat(amps,labels);
        % Convert the integer label vector to a class-identifier matrix.
        [~,grplabels] = ismember(labels,isLabels); 
        labelMat = zeros(nlabels,n); 
        idxLinear = sub2ind([nlabels n],grplabels',(1:n)'); 
        labelMat(idxLinear) = 1; % Flags the row corresponding to the class 
        [~,grpY] = ismember(amps,isLabels); 
        YMat = zeros(nlabels,n); 
        idxLinearY = sub2ind([nlabels n],grpY,(1:n)'); 
        YMat(idxLinearY) = 1; 

        figure;
        plotconfusion(YMat,labelMat);
        h = gca;
        h.XTickLabel = [num2cell(isLabels); {''}];
        h.YTickLabel = [num2cell(isLabels); {''}];

    end
      
    % multi_loss with n electrodes versus multi_loss with one electrode
    loss_ratio(f,:) = multi_loss(f,:)/multi_loss(f,1);
    display(loss_ratio(f,:));
    
end
 
% save the data
save(filename,'files','nelec','runs','binsize','multi_loss',...
    'multi_std','loss_ratio','all_amps','all_labels','description');